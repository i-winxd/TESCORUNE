BigShotLibrary by vitellary

a yellow soul library for kristal! see https://github.com/vitellaryjr/BigShotLibrary for documentation and downloads and such